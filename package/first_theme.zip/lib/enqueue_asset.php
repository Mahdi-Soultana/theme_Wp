<?php 

function first_theme_assets(){

    wp_enqueue_style("first_theme_StyleSheet",get_template_directory_uri() ."/dist/asset/src/css/bundel.css"
    ,NULL,"1.0","all");

    wp_enqueue_script( "first_theme_Main_Js", get_template_directory_uri() .'/dist/asset/js/bundle.js', array("jquery"),"1.0.0", true );

    

}

add_action("wp_enqueue_scripts","first_theme_assets");

function first_theme_admin_assets(){

    wp_enqueue_style("first_theme_StyleSheet",get_template_directory_uri() ."/dist/asset/src/css/admin.css"
    ,NULL,"1.0","all");

    wp_enqueue_script( "first_theme_admin_Js", get_template_directory_uri() .'/dist/asset/js/admin.js', array(),"1.0.0", true );



}

add_action("admin_enqueue_scripts","first_theme_admin_assets");
