<?php get_header()?>

Index

<?php get_footer()?>